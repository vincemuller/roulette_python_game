#Portfolio Project
#Roulette Application in Python
#By Vince Muller

import os #Module for clearing the terminal
from roulette_pkg.homepage import gamegraphic #Module with functions for game graphics and displays

#Class for creating a new player/user
class user():
    def __init__(self):
        self.name = ""
        self.password = ""
        self.deposit = 0

    def register(self):
        while True:
            os.system('clear')
            gamegraphic()
            self.name = input("Create Username: ")
            self.password = input("Create Password: ")
            self.deposit = input("Starting Deposit: $")
            return self.name, self.password, self.deposit

#Function for accepting user inputs to authenticate and log in an existing user
def login():
    os.system('clear')
    gamegraphic()
    name = input("Username: ")
    password = input("Password: ")
    return name, password