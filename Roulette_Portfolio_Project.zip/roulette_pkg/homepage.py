#Portfolio Project
#Roulette Application in Python
#By Vince Muller

import os #Module for clearing the terminal

#Function for displaying homepage graphic
def gamegraphic():
    os.system('clear')
    print("-------------------------------------------------------------------------")
    print(" /$$$$$$$                      /$$             /$$     /$$              ")
    print("| $$__  $$                    | $$            | $$    | $$              ")
    print("| $$  \ $$  /$$$$$$  /$$   /$$| $$  /$$$$$$  /$$$$$$ /$$$$$$    /$$$$$$ ")
    print("| $$$$$$$/ /$$__  $$| $$  | $$| $$ /$$__  $$|_  $$_/|_  $$_/   /$$__  $$")
    print("| $$__  $$| $$  \ $$| $$  | $$| $$| $$$$$$$$  | $$    | $$    | $$$$$$$$")
    print("| $$  \ $$| $$  | $$| $$  | $$| $$| $$_____/  | $$ /$$| $$ /$$| $$_____/")
    print("| $$  | $$|  $$$$$$/|  $$$$$$/| $$|  $$$$$$$  |  $$$$/|  $$$$/|  $$$$$$$")
    print("|__/  |__/ \______/  \______/ |__/ \_______/   \___/   \___/   \_______")
    print("-------------------------------------------------------------------------")

#Function for capturing homepage user selection
def startgame():
    gamegraphic()
    homepage_selection = ""

    while True:
        print("|   1. Create Account    |      2. Log In      |      3. Exit Game      |")
        print("-------------------------------------------------------------------------")
        homepage_selection = input("\nSelect an option: ")

        if homepage_selection == "":
            homepage_selection == "4"
        return homepage_selection


