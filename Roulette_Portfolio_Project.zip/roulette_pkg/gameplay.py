#Portfolio Project
#Roulette Application in Python
#By Vince Muller

import os #Module for clearing the terminal
import random #Module for random selection functionality
from time import sleep #Module for timed printing

#from colorama import Fore, Back, Style (Leaving for future iterations)

#Global list variables for board value options
roulettewheel = ['0', '1b', '2r', '3b', '4r', '5b', '6r', '7b', '8r', '9b', '10r', '11b', '12r', '13b', '14r', '15b', '16r', '17b', '18r', '19b', '20r', '21b', '22r', '23b', '24r', '25b', '26r', '27b', '28r', '29b', '30r', '31b', '32r', '33b', '34r', '35b', '36r']
first12list = ['1b', '2r', '3b', '4r', '5b', '6r', '7b', '8r', '9b', '10r', '11b', '12r']
second12list = ['13b', '14r', '15b', '16r', '17b', '18r', '19b', '20r', '21b', '22r', '23b', '24r']
third12list = ['25b', '26r', '27b', '28r', '29b', '30r', '31b', '32r', '33b', '34r', '35b', '36r']
toplist = ['3b', '6r', '9b', '12r', '15b', '18r', '21b', '24r', '27b', '30r', '33b', '36r']
mdllist = ['2r', '5b', '8r', '11b', '14r', '17b', '20r', '23b', '26r', '29b', '32r', '35b']
btmlist = ['1b', '4r', '7b', '10r', '13b', '16r', '19b', '22r', '25b', '28r', '31b', '34r']
evenredlist = ['2r', '4r', '6r', '8r', '10r', '12r', '14r', '16r', '18r', '20r', '22r', '24r', '26r', '28r', '30r', '32r', '34r', '36r']
oddblacklist = ['1b', '3b', '5b', '7b', '9b', '11b', '13b', '15b', '17b', '19b', '21b', '23b', '25b', '27b', '29b', '31b', '33b', '35b']
first18list = ['1b', '2r', '3b', '4r', '5b', '6r', '7b', '8r', '9b', '10r', '11b', '12r', '13b', '14r', '15b', '16r', '17b', '18r']
last18llist = ['19b', '20r', '21b', '22r', '23b', '24r', '25b', '26r', '27b', '28r', '29b', '30r', '31b', '32r', '33b', '34r', '35b', '36r']

#Game play graphic and display
def gameplaygraphic(username, balance):
      print("               ____                    _          _     _          ")
      print("              |  _ \    ___    _   _  | |   ___  | |_  | |_    ___ ")
      print("              | |_) |  / _ \  | | | | | |  / _ \ | __| | __|  / _ \ ")
      print("              |  _ <  | (_) | | |_| | | | |  __/ | |_  | |_  |  __/")
      print("              |_| \_\  \___/   \__,_| |_|  \___|  \__|  \__|  \___|")
      print("-----------------------------------------------------------------------------------")
      print("|     | 3B | 6R | 9B | 12R | 15B | 18R | 21B | 24R | 27B | 30R | 33B | 36R | top  |")
      print("|     |----------------------------------------------------------------------------")
      print("|  0  | 2R | 5B | 8R | 11B | 14R | 17B | 20R | 23B | 26R | 29B | 32R | 35B | mdl  |")
      print("|     |----------------------------------------------------------------------------")
      print("|     | 1B | 4R | 7B | 10R | 13B | 16R | 19B | 22R | 25B | 28R | 31B | 34R | btm  |")
      print("-----------------------------------------------------------------------------------")
      print("      |        1st12       |         2nd12         |          3rd12        |")
      print("      ----------------------------------------------------------------------")
      print("      |  1to18  |   EVEN   |    RED    |   BLACK   |    ODD    |   19to36  |")
      print("      ----------------------------------------------------------------------")

#Game play function with options to: bet, spin, clear bets, log out, deposit and cash out
def gameplay(username, balance):
      totalbet = 0 #Temporary game play variable for displaying active user bets
      betdict = {} #Temporary game play dictionary for storing user bets

      while True:
            #Game play dynamic display showing player's name, total bet and current balance
            #User can select option by entering the number
            list_of_the_keys = list(betdict.keys())
            os.system('clear')
            gameplaygraphic(username, balance)
            print("      Player: ", username, "          Total Bet: $",
                  totalbet, "          Balance: $", balance)
            print("\n      Current Bets: ", ', '.join(list_of_the_keys))
            print("\n     1. BET   2. SPIN   3. CLEAR   4. SAVE & LOG OUT   5. DEPOSIT   6. CASHOUT")
            gameselection = input("\n                          Select an option: ")

      #Game actions based on game selection
            #User inputs new bet and associated variables are updated
            if gameselection == "1":
                  try:
                        os.system('clear')
                        gameplaygraphic(username, balance)
                        print("      Player: ", username, "          Total Bet: $",
                        totalbet, "          Balance: $", balance)
                        print("\n      Current Bets: ", ', '.join(list_of_the_keys))

                        #Collecting users bet amount and board value
                        betamount = int(input("\n      Bet Amount: $"))
                        bet = input("      Board value betting on: ")

                        #Checking validity of bet
                        if betamount > balance or betamount < 1:
                              input("      Invalid Bet Amount")
                              continue

                        #If statements to check and assign payout rates based on user bet
                        #Add board value with pay out calculations to temporary bet dictionary
                        if bet.lower() == "1st12" or bet.lower() == "2nd12" or bet.lower() == "3rd12" or bet.lower() == "top" or bet.lower() == "mdl" or bet.lower() == "btm":
                              betdict[bet.lower()] = 3 * betamount
                              totalbet = totalbet + betamount
                              balance = balance - betamount
                        elif bet.lower() == "1to18" or bet.lower() == "19to36" or bet.lower() == "red" or bet.lower() == "black" or bet.lower() == "odd" or bet.lower() == "even":
                              betdict[bet.lower()] = 2 * betamount
                              totalbet = totalbet + betamount
                              balance = balance - betamount
                        elif bet.lower() in roulettewheel:
                              betdict[bet.lower()] = 35 * betamount
                              totalbet = totalbet + betamount
                              balance = balance - betamount
                        else:
                              input("      Invalid Board Value")
                  except:
                        input("      Invalid Bet Amount")

            #User spins roulette wheel, selecting board value at random and comparing random spin value to active bets
            if gameselection == "2":
                  spinlist = [] #Temporary list to collect spin value and all associated board values
                  winnings = 0
                  spin = random.choice(roulettewheel)

                  #Game play graphic and display
                  os.system('clear')
                  gameplaygraphic(username, balance)
                  print("      Player: ", username, "          Total Bet: $",
                  totalbet, "          Balance: $", balance)
                  print("\n      Current Bets: ", ', '.join(list_of_the_keys))

                  #Game play animation for spinning roulette wheel
                  for x in range(5):
                        print("-----------------------------------spinning----------------------------------------")
                        sleep(.50)
                  print("\n                           The ball landed on: " + spin)

                  spinlist.append(spin)

                  #If statements to add all alternative board values to spin list
                  if spin in first12list:
                        spinlist.append("1st12")
                  if spin in second12list:
                        spinlist.append("2nd12")
                  if spin in third12list:
                        spinlist.append("3rd12")
                  if spin in toplist:
                        spinlist.append("top")
                  if spin in mdllist:
                        spinlist.append("mdl")
                  if spin in btmlist:
                        spinlist.append("btm")
                  if spin in evenredlist:
                        spinlist.append("even")
                        spinlist.append("red")
                  if spin in oddblacklist:
                        spinlist.append("odd")
                        spinlist.append("black")
                  if spin in first18list:
                        spinlist.append("1to18")
                  if spin in last18llist:
                        spinlist.append("19to36")

                  #Compare spin values to active bets, calculate winnings and add to player balance
                  for keys, value in betdict.items():
                        if keys in spinlist:
                              balance = balance + betdict[keys]
                              winnings = winnings + betdict[keys]

                  #Comms to player informing them if they won or lost
                  if winnings > 0:
                        print("                           Congrats!  You won: $", winnings)
                  else:
                        print("                      You did not win, please play again")
                  input()
                  totalbet = 0
                  betdict = {}

            #Clears active user bets and associated variables
            if gameselection == "3":
                  balance = balance + totalbet
                  totalbet = 0
                  betdict = {}

            #Saves users balance, logs them out and returns them to homepage
            if gameselection == "4":
                  balance = balance + totalbet
                  return username, balance

            #Allows user to deposit additional funds and increase balance
            if gameselection == "5":
                  deposit = 0
                  os.system('clear')
                  gameplaygraphic(username, balance)
                  print("      Player: ", username, "          Total Bet: $",
                  totalbet, "          Balance: $", balance)

                  deposit = int(input("\n      Deposit Amount: $"))
                  balance = balance + deposit

            #Allows user to pull money from balance, updates balance to 0 and returns user to homepage
            if gameselection == "6":
                  os.system('clear')
                  gameplaygraphic(username, balance)
                  print("                          $", balance + totalbet, " has been cashed out")
                  input("                             Thank you for playing")
                  balance = 0
                  return username, balance
